from django.apps import AppConfig


class StarkConfig(AppConfig):
    name = 'Stark'
