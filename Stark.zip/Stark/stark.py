from django.conf.urls import url
from django.http import HttpResponse
from django.shortcuts import render,reverse
from django.utils.safestring import mark_safe
class StarkModel(object):




    display = ["__str__"]

    display_links = []

    def check_box(self, obj=None,header=False):
        if header:
            return mark_safe("<input type='checkbox' class='choice'/>" )
        return mark_safe("<input  type='checkbox' class='choice_item'/>" )

    def __init__(self,model,site):
        self.model = model
        self.site = site

    def edit(self, obj=None,header=False):
        if header:
            return "操作"

        # print("_url", _url)
        return mark_safe("<a href='%s'>编辑</a>" % self.get_reverse_url(obj))

    def delete_view(self, obj=None,header=False):
        if header:
            return "删除"
        app_name = self.model._meta.app_label
        model_name = self.model._meta.model_name
        _url = reverse("%s_%s_delete" % (app_name, model_name), args=(obj.pk,))  # api_user_list
        print("_url", _url)
        return mark_safe("<a href='%s'>删除</a>" % _url)


    def get_reverse_url(self,obj):
        app_name = self.model._meta.app_label
        model_name = self.model._meta.model_name
        _url = reverse("%s_%s_change" % (app_name, model_name), args=(obj.pk,))  # api_user_list
        return _url

    @property
    def get_urls2(self):
        return self.getOptions(), None, None

    def getOptions(self):
        app_name = self.model._meta.app_label
        model_name = self.model._meta.model_name
        option_list = []
        option_list.append(url(r'^add/$', self.add,name='%s_%s_add'%(app_name,model_name)))
        option_list.append(url(r'^(\d+)/delete/$', self.delete,name='%s_%s_delete'%(app_name,model_name)))
        option_list.append(url(r'^(\d+)/change/$', self.change,name='%s_%s_change'%(app_name,model_name)))
        option_list.append(url(r'^$', self.list,name='%s_%s_list'%(app_name,model_name)))
        return option_list

    def add(self, request):
        return HttpResponse("ok")


    def new_display(self):
        temp = []
        temp.append(StarkModel.check_box)
        temp.extend(self.display)
        if not self.display_links:
            temp.append(StarkModel.edit)
        temp.append(StarkModel.delete_view)
        return temp


    def list(self,request):
        datalist = self.model.objects.all()
        print("self.display", self.display)
        data_array = []

        head_list = []
        for fields in self.new_display():  # [checkbox,'name','age',edit]
            if callable(fields):
                val= fields(self,header=True)
                head_list.append(val)
            else:
                if fields == "__str__":
                    head_list.append(self.model._meta.model_name.upper())
                else:
                    fields_obj = self.model._meta.get_field(fields)
                    head_list.append(fields_obj.verbose_name)



        print("display",self.display)
        for obj in datalist:                    #data  [obj,obj]
            temp = []
            for field in self.new_display():          #['name','age',edit]  field ==='name'
                if callable(field):             #如何传来的是函数，就调用方法得到返回值
                    val = field(self,obj)
                else:
                    if field in self.display_links:
                        val = getattr(obj,field)
                        val = mark_safe("<a href='%s'>%s</a>"%(self.get_reverse_url(obj),val))
                    else:
                        val = getattr(obj,field)
                temp.append(val)
            data_array.append(temp)

        return render(request,'stark/data.html',{"data":data_array,"head_list":head_list})


    def delete(self,request,id):
        print(id)
        return HttpResponse("delete")

    def change(self,request,id):
        return HttpResponse("change")



class StarkAdmin(object):
    def __init__(self):
        self._registry = {}

    def register(self, model_class, admin_class=None, **options):

        """注册admin表"""

        # print("register",model_class,admin_class)
        app_name = model_class._meta.app_label
        # model_name = model_class._meta.model_name
        if not admin_class:  # 为了避免多个model共享同一个BaseKingAdmin内存对象
            admin_class = StarkModel
        # else:
        #     admin_class = admin_class()

        #admin_class.model = model_class  # 把model_class赋值给了admin_class
        #
        # if app_name not in self._registry:
        #     self._registry[model_class] = {}
        self._registry[model_class] = admin_class(model_class,self)

    @property
    def urls(self):
        return self.get_urls(), None,None

    def get_urls(self):

        urlpatterns = []
        for model_class,admin_class_obj in self._registry.items():
            app_label = model_class._meta.app_label
            model_name = model_class._meta.model_name
            urlpatterns.append(url(r'^%s/%s/'%(app_label,model_name),admin_class_obj.get_urls2))
        return urlpatterns


sites = StarkAdmin()
