from django.conf.urls import url,include
from Stark import views



urlpatterns = [

    url(r'',views.acc_login)
]